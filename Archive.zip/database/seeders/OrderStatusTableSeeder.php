<?php

namespace Database\Seeders;

use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Status;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class OrderStatusTableSeeder extends Seeder
{
    public function run()
    {
        //DB::table('order_status')->delete();

        // OrderStatusSeeder
        $statuses = Status::all();
        //number of status defined for each order
        $nbrStatuses = 4;

        foreach (Order::all() as $order) {
            $statusesCount = rand(1, $nbrStatuses);
            $time = Carbon::today();
            for ($i = 1; $i <= $statusesCount; $i++) {
                $time->addSecond();
                OrderStatus::create([
                    'order_id' => $order->id,
                    'status_id' => $i,
                    'created_at' => $time
                ]);
            }
        }
    }
}
